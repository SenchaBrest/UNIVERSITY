﻿// using System;

// interface IContainer
// {
//     void ShowVolume();
//     double Volume();
// }

// class Box : IContainer
// {
//     private double m_Length;
//     private double m_Width;
//     private double m_Height;

//     public void ShowVolume()
//     {
//         Console.WriteLine("Полезный объем Box равен {0}", Volume());
//     }

//     public double Volume()
//     {
//         return m_Length * m_Width * m_Height;
//     }

//     public Box()
//     {
//         m_Length = 1.0;
//         m_Width = 1.0;
//         m_Height = 1.0;
//     }

//     public Box(double lv, double wv, double hv)
//     {
//         m_Length = lv;
//         m_Width = wv;
//         m_Height = hv;
//     }
// }


// class Program
// {
//     static void Main(string[] args)
//     {
//         // Создание объекта Box с размерами по умолчанию
//         Box defaultBox = new Box();
//         Console.WriteLine("Размеры контейнера по умолчанию:");
//         defaultBox.ShowVolume();

//         // Создание объекта Box с пользовательскими размерами
//         Box customBox = new Box(2.5, 3.0, 1.8);
//         Console.WriteLine("Пользовательские размеры контейнера:");
//         customBox.ShowVolume();

//         Console.ReadLine();
//     }
// }
