/*using System;

class Program
{
    static void Main()
    {
        // Создаем массив со случайными значениями
        int[] array = new int[10];
        Random random = new Random();
        for (int i = 0; i < array.Length; i++)
        {
            array[i] = random.Next(100);
        }

        // Находим максимальное значение в массиве
        int max = array[0];
        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] > max)
            {
                max = array[i];
            }
        }

        // Выводим массив и максимальное значение
        Console.WriteLine("Массив:");
        Console.WriteLine(string.Join(" ", array));
        Console.WriteLine($"Максимальное значение: {max}");
    }
}
*/