/*using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите текст: ");
        string text = Console.ReadLine().ToLower();

        int vowels = 0;
        int consonants = 0;

        foreach (char c in text)
        {
            if (char.IsLetter(c))
            {
                if ("aeiouy".IndexOf(c) != -1)
                {
                    vowels++;
                }
                else
                {
                    consonants++;
                }
            }
        }

        Console.WriteLine($"Количество гласных букв: {vowels}");
        Console.WriteLine($"Количество согласных букв: {consonants}");
    }
}
*/