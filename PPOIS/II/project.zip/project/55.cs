// using System;

// class MatrixOperations
// {
//     static void Main()
//     {
//         int[,] matrixA = { { 1, 2 }, { 3, 4 } };
//         int[,] matrixB = { { 5, 6 }, { 7, 8 } };

//         int[,] product = MultiplyMatrices(matrixA, matrixB);
//         Console.WriteLine("Matrix product:");
//         PrintMatrix(product);

//         int[,] transpose = TransposeMatrix(product);
//         Console.WriteLine("Matrix transpose:");
//         PrintMatrix(transpose);
//     }

//     static int[,] MultiplyMatrices(int[,] matrixA, int[,] matrixB)
//     {
//         int rowsA = matrixA.GetLength(0);
//         int colsA = matrixA.GetLength(1);
//         int rowsB = matrixB.GetLength(0);
//         int colsB = matrixB.GetLength(1);

//         if (colsA != rowsB)
//         {
//             throw new ArgumentException("Matrix dimensions are not compatible for multiplication.");
//         }

//         int[,] result = new int[rowsA, colsB];

//         for (int i = 0; i < rowsA; i++)
//         {
//             for (int j = 0; j < colsB; j++)
//             {
//                 int sum = 0;
//                 for (int k = 0; k < colsA; k++)
//                 {
//                     sum += matrixA[i, k] * matrixB[k, j];
//                 }
//                 result[i, j] = sum;
//             }
//         }

//         return result;
//     }

//     static int[,] TransposeMatrix(int[,] matrix)
//     {
//         int rows = matrix.GetLength(0);
//         int cols = matrix.GetLength(1);

//         int[,] result = new int[cols, rows];

//         for (int i = 0; i < rows; i++)
//         {
//             for (int j = 0; j < cols; j++)
//             {
//                 result[j, i] = matrix[i, j];
//             }
//         }

//         return result;
//     }

//     static void PrintMatrix(int[,] matrix)
//     {
//         int rows = matrix.GetLength(0);
//         int cols = matrix.GetLength(1);

//         for (int i = 0; i < rows; i++)
//         {
//             for (int j = 0; j < cols; j++)
//             {
//                 Console.Write(matrix[i, j] + "\t");
//             }
//             Console.WriteLine();
//         }
//     }
// }
