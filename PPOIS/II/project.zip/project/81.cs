﻿// using System;

// public struct Height
// {
//     public int Feet { get; }
//     public int Inches { get; }

//     public Height(int inches)
//     {
//         Feet = inches / 12;
//         Inches = inches % 12;
//     }

//     public Height(int feet, int inches)
//     {
//         Feet = feet;
//         Inches = inches;
//     }

//     public override string ToString()
//     {
//         return $"{Feet} футов {Inches} дюймов";
//     }
// }

// class Program
// {
//     static void Main(string[] args)
//     {
//         Height myHeight = new Height(6, 3);
//         Height yourHeight = new Height(70);
//         Height hisHeight = yourHeight;

//         Console.WriteLine("Мой рост: " + myHeight);
//         Console.WriteLine("Твой рост: " + yourHeight);
//         Console.WriteLine("Его рост: " + hisHeight);

//         Console.ReadKey();
//     }
// }
