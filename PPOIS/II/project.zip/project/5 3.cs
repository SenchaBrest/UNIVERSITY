/*using System;

class Program
{
    static void Main()
    {
        // Создаем две матрицы
        int[,] matrixA = new int[3, 2] { { 1, 2 }, { 3, 4 }, { 5, 6 } };
        int[,] matrixB = new int[2, 4] { { 7, 8, 9, 10 }, { 11, 12, 13, 14 } };

        // Выводим исходные матрицы на консоль
        Console.WriteLine("Матрица A:");
        PrintMatrix(matrixA);
        Console.WriteLine("Матрица B:");
        PrintMatrix(matrixB);

        // Вычисляем произведение матриц A и B
        int[,] product = MultiplyMatrices(matrixA, matrixB);

        // Выводим произведение матриц на консоль
        Console.WriteLine("Произведение матриц A и B:");
        PrintMatrix(product);

        // Транспонируем матрицу A
        int[,] transposed = TransposeMatrix(matrixA);

        // Выводим транспонированную матрицу на консоль
        Console.WriteLine("Транспонированная матрица A:");
        PrintMatrix(transposed);
    }

    // Функция для вычисления произведения матриц
    static int[,] MultiplyMatrices(int[,] matrixA, int[,] matrixB)
    {
        int rowsA = matrixA.GetLength(0);
        int colsA = matrixA.GetLength(1);
        int colsB = matrixB.GetLength(1);

        int[,] product = new int[rowsA, colsB];

        for (int i = 0; i < rowsA; i++)
        {
            for (int j = 0; j < colsB; j++)
            {
                for (int k = 0; k < colsA; k++)
                {
                    product[i, j] += matrixA[i, k] * matrixB[k, j];
                }
            }
        }

        return product;
    }

    // Функция для транспонирования матрицы
    static int[,] TransposeMatrix(int[,] matrix)
    {
        int rows = matrix.GetLength(0);
        int cols = matrix.GetLength(1);

        int[,] transposed = new int[cols, rows];

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                transposed[j, i] = matrix[i, j];
            }
        }

        return transposed;
    }

    // Функция для вывода матрицы на консоль
    static void PrintMatrix(int[,] matrix)
    {
        int rows = matrix.GetLength(0);
        int cols = matrix.GetLength(1);

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
        Console.WriteLine();
    }
}
*/