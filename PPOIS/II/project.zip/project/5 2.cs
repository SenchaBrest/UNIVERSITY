/*using System;

class Program
{
    static void Main()
    {
        // Создаем трехмерный массив со случайными значениями
        int[,,] array = new int[3, 4, 5];
        Random random = new Random();
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                for (int k = 0; k < 5; k++)
                {
                    array[i, j, k] = random.Next(100);
                }
            }
        }

        // Находим максимальное значение в массиве
        int max = array[0, 0, 0];
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                for (int k = 0; k < 5; k++)
                {
                    if (array[i, j, k] > max)
                    {
                        max = array[i, j, k];
                    }
                }
            }
        }

        // Выводим массив и максимальное значение
        Console.WriteLine("Массив:");
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                for (int k = 0; k < 5; k++)
                {
                    Console.Write(array[i, j, k] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
        Console.WriteLine($"Максимальное значение: {max}");
    }
}
*/