﻿/*using System;
namespace ConsoleApplication1
{
    class Class1
    {
        static void Main()
        {
            Console.WriteLine("Введите строчку" );
            string s = Console.ReadLine();
            Console.WriteLine( "s= " + s);

            Console.WriteLine("Введите символ");
            char c = (char)Console.Read();
            Console.ReadLine();
            Console.WriteLine("c= " + c);
            string buf;
            Console.WriteLine("Введите целое число");
            buf = Console.ReadLine();
            int i = Convert.ToInt32( buf );
            Console.WriteLine( i );

            Console.WriteLine("Введите вещественное число");
            buf = Console.ReadLine();
            double x = Convert.ToDouble( buf );
            Console.WriteLine( x );

            Console.WriteLine("Введите вещественное значение");
            buf = Console.ReadLine();
            double y = double.Parse( buf );
            Console.WriteLine( y );

            Console.WriteLine("Введите вещественное значение");
            buf = Console.ReadLine();
            decimal z = decimal.Parse( buf );
            Console.WriteLine( z );
        }
    }
}*/