﻿// using System;

// class Length
// {
//     private int feet;
//     private int inches;
//     public static readonly int inchesPerFoot = 12;

//     // Конструктор
//     public Length(int ft, int ins)
//     {
//         feet = ft;
//         inches = ins;
//     }

//     // Длина в виде строки
//     public override string ToString()
//     {
//         string result = feet.ToString() + (1 == feet ? " foot " : " feet ") + inches.ToString() + (1 == inches ? " inch" : " inches");
//         return result;
//     }

//     // Перегруженный оператор сложения
//     public static Length operator +(Length len1, Length len2)
//     {
//         int inchTotal = len1.inches + len2.inches + inchesPerFoot * (len1.feet + len2.feet);
//         return new Length(inchTotal / inchesPerFoot, inchTotal % inchesPerFoot);
//     }

//     // Перегруженный оператор деления - правый операнд типа double
//     public static Length operator /(Length len, double x)
//     {
//         int ins = (int)((len.feet * Length.inchesPerFoot + len.inches) / x);
//         return new Length(ins / Length.inchesPerFoot, ins % Length.inchesPerFoot);
//     }

//     // Перегруженный оператор деления - оба операнда типа Length
//     public static int operator /(Length len1, Length len2)
//     {
//         return (len1.feet * Length.inchesPerFoot + len1.inches) / (len2.feet * Length.inchesPerFoot + len2.inches);
//     }

//     // Перегруженный оператор остатка от деления
//     public static Length operator %(Length len1, Length len2)
//     {
//         int ins = (len1.feet * Length.inchesPerFoot + len1.inches) % (len2.feet * Length.inchesPerFoot + len2.inches);
//         return new Length(ins / Length.inchesPerFoot, ins % Length.inchesPerFoot);
//     }

//     // Перегруженный оператор умножения - правый операнд типа double
//     public static Length operator *(double x, Length len)
//     {
//         int ins = (int)(x * len.inches + x * len.feet * Length.inchesPerFoot);
//         return new Length(ins / Length.inchesPerFoot, ins % Length.inchesPerFoot);
//     }

//     // Перегруженный оператор умножения - левый операнд типа double
//     public static Length operator *(Length len, double x)
//     {
//         return x * len;
//     }

//     // Префиксный и постфиксный операторы инкремента
//     public static Length operator ++(Length len)
//     {
//         Length temp = new Length(len.feet, len.inches);
//         temp.feet += temp.inches / Length.inchesPerFoot;
//         temp.inches %= Length.inchesPerFoot;
//         return temp;
//     }
// }
