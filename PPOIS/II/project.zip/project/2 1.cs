/*using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите начальное значение x: ");
        double x0 = double.Parse(Console.ReadLine());

        Console.Write("Введите конечное значение x: ");
        double x1 = double.Parse(Console.ReadLine());

        Console.Write("Введите шаг: ");
        double dx = double.Parse(Console.ReadLine());

        Console.WriteLine("x\t y");

        for (double x = x0; x <= x1; x += dx)
        {
            double y = Math.Sin(x) / x;
            Console.WriteLine($"{x:0.000}\t {y:0.000}");
        }
    }
}
*/