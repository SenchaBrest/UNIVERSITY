/*using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите букву: ");
        char letter = char.Parse(Console.ReadLine());

        if (char.IsLower(letter))
        {
            Console.WriteLine("Это строчная буква.");
        }
        else if (char.IsUpper(letter))
        {
            Console.WriteLine("Это прописная буква.");
        }
        else
        {
            Console.WriteLine("Это не буква.");
        }
    }
}
*/