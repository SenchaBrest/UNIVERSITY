// using System;

// class Program
// {
//     static void Main()
//     {
//         // 一维数组
//         int[] 一维数组 = { 1, 2, 3, 4, 5 };
//         int 一维数组总和 = 计算数组总和(一维数组);
//         Console.WriteLine($"一维数组的总和：{一维数组总和}");

//         // 二维数组
//         int[,] 二维数组 = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
//         int 二维数组总和 = 计算数组总和(二维数组);
//         Console.WriteLine($"二维数组的总和：{二维数组总和}");

//         // 不规则数组
//         int[][] 不规则数组 = new int[3][];
//         不规则数组[0] = new int[] { 1, 2, 3, 4 };
//         不规则数组[1] = new int[] { 5, 6 };
//         不规则数组[2] = new int[] { 7, 8, 9 };
//         int 不规则数组总和 = 计算不规则数组总和(不规则数组);
//         Console.WriteLine($"不规则数组的总和：{不规则数组总和}");
//     }

//     static int 计算数组总和(int[] 数组)
//     {
//         int 总和 = 0;
//         foreach (int 数字 in 数组)
//         {
//             总和 += 数字;
//         }
//         return 总和;
//     }

//     static int 计算数组总和(int[,] 数组)
//     {
//         int 总和 = 0;
//         int 长度1 = 数组.GetLength(0);
//         int 长度2 = 数组.GetLength(1);
//         for (int i = 0; i < 长度1; i++)
//         {
//             for (int j = 0; j < 长度2; j++)
//             {
//                 总和 += 数组[i, j];
//             }
//         }
//         return 总和;
//     }

//     static int 计算不规则数组总和(int[][] 数组)
//     {
//         int 总和 = 0;
//         foreach (int[] 子数组 in 数组)
//         {
//             foreach (int 数字 in 子数组)
//             {
//                 总和 += 数字;
//             }
//         }
//         return 总和;
//     }
// }
