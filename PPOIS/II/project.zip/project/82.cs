﻿// using System;

// public struct Height
// {
//     public int Feet { get; set; }
//     public int Inches { get; }

//     public Height(int inches)
//     {
//         Feet = inches / 12;
//         Inches = inches % 12;
//     }

//     public Height(int feet, int inches)
//     {
//         Feet = feet;
//         Inches = inches;
//     }

//     public override string ToString()
//     {
//         return $"{Feet} футов {Inches} дюймов";
//     }
// }

// class Program
// {
//     static void Main(string[] args)
//     {
//         Height myHeight = new Height(6, 3);
//         ref Height yourHeight = ref myHeight;
//         Height hisHeight = yourHeight;

//         Console.WriteLine("Мой рост: " + myHeight);
//         Console.WriteLine("Твой рост: " + yourHeight);
//         Console.WriteLine("Его рост: " + hisHeight);

//         Console.WriteLine("Изменение роста (Feet) на -1");
//         yourHeight.Feet = -1; // Изменение роста через ссылку
//         if (yourHeight.Feet < 0)
//         {
//             Console.WriteLine("Ошибка! Число меньше 0!");
//         }
//         else
//         {
//             Console.WriteLine("Измененный рост: " + myHeight);
//         }

//         Console.ReadKey();
//     }
// }
