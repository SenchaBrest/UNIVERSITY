﻿// using System;

// class AboutSwap
// {
//     private int a;
//     private int b;

//     public AboutSwap(int a, int b)
//     {
//         this.a = a;
//         this.b = b;
//     }

//     public void ToShow()
//     {
//         Console.WriteLine($"Значения: a = {a}, b = {b}");
//     }

//     public static void SwapValues(AboutSwap obj1, AboutSwap obj2)
//     {
//         int tempA = obj1.a;
//         int tempB = obj1.b;

//         obj1.a = obj2.a;
//         obj1.b = obj2.b;

//         obj2.a = tempA;
//         obj2.b = tempB;
//     }

//     public static AboutSwap AboutSwapObject(int i, int j)
//     {
//         AboutSwap newObj = new AboutSwap(i, j);
//         return newObj;
//     }
// }

// class Program
// {
//     static void Main()
//     {
//         AboutSwap obj1 = new AboutSwap(10, 20);
//         AboutSwap obj2 = new AboutSwap(30, 40);

//         Console.WriteLine("Объект 1 до обмена:");
//         obj1.ToShow();

//         Console.WriteLine("Объект 2 до обмена:");
//         obj2.ToShow();

//         AboutSwap.SwapValues(obj1, obj2);

//         Console.WriteLine("Объект 1 после обмена:");
//         obj1.ToShow();

//         Console.WriteLine("Объект 2 после обмена:");
//         obj2.ToShow();

//         AboutSwap obj3 = AboutSwap.AboutSwapObject(50, 60);
//         Console.WriteLine("Новый объект:");
//         obj3.ToShow();
//     }
// }
