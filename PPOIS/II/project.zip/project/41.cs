/*using System;

class Program
{
    static void Main()
    {
        ConsoleKeyInfo keyInfo;

        do
        {
            keyInfo = Console.ReadKey(true);
            Console.WriteLine("Вы нажали клавишу: " + keyInfo.KeyChar);
        } while (keyInfo.Key != ConsoleKey.Escape);
    }
}
*/