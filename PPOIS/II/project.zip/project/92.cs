﻿// using System;

// class Box
// {
//     private double length;
//     private double width;
//     private double height;

//     // Конструктор без аргументов
//     public Box()
//     {
//         Console.WriteLine("Создан куб по умолчанию");
//     }

//     // Обычный конструктор
//     public Box(double length, double width, double height)
//     {
//         Console.WriteLine("Создан новый куб");
//         this.length = length;
//         this.width = width;
//         this.height = height;
//     }

//     // Метод для вычисления объема куба
//     public double CalculateVolume()
//     {
//         return length * width * height;
//     }

//     public double prLength
//     {
//         get { return length; }
//         set
//         {
//             if (value >= 0)
//                 length = value;
//             else
//                 Console.WriteLine("Значение должно быть неотрицательным");
//         }
//     }
// }

// class Program
// {
//     static void Main(string[] args)
//     {
//         double length;
//         // Создание куба по умолчанию
//         Box defaultBox = new Box();
//         double defaultVolume = defaultBox.CalculateVolume();
//         Console.WriteLine("Объем куба по умолчанию: " + defaultVolume);

//         // Ввод значений длины, ширины и высоты для нового ящика через класс
//         double value = GetDoubleInput("Введите длину куба: ");
//         if (value >= 0)
//         {
//             length = value;
//         }
//         else
//         {
//             Console.WriteLine("Значение должно быть неотрицательным");
//             return;
//         }
//         double width = GetDoubleInput("Введите ширину куба: ");
//         double height = GetDoubleInput("Введите высоту куба: ");

//         // Создание нового ящика с введенными значениями
//         Box customBox = new Box(length, width, height);
//         double customVolume = customBox.CalculateVolume();
//         Console.WriteLine("Объем нового ящика: " + customVolume);

//         Console.ReadKey();
//     }

//     // Метод для ввода числового значения с проверкой
//     static double GetDoubleInput(string message)
//     {
//         double result;
//         bool isValidInput = false;

//         do
//         {
//             Console.Write(message);
//             isValidInput = double.TryParse(Console.ReadLine(), out result);

//             if (!isValidInput)
//             {
//                 Console.WriteLine("Ошибка ввода. Попробуйте еще раз.");
//             }
//         } while (!isValidInput);

//         return result;
//     }
// }
