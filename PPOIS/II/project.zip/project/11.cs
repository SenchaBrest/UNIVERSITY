/*using System;
namespace ConsoleApplication2
{
    class Program
    {
        static void Main()
        {
            string buf;
            double u, i, r;
            try
            {
                Console.WriteLine("Введите напряжение");
                buf = Console.ReadLine();
                u = double.Parse(buf);
                Console.WriteLine("Введите сопротивление");
                buf = Console.ReadLine();
                r = double.Parse(buf);
                i = u / r;
                Console.WriteLine("Сила тока равна " + i);
            }
            catch (FormatException)
            {
                Console.WriteLine("Неверный формат введенных данных");
            }
            catch
            {
                Console.WriteLine("Неизвестная ошибка");
            }
        }
    }
}*/